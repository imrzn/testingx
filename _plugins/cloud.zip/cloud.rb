require 'json'
require 'fileutils'
require 'open-uri'
require 'openssl'
require 'base64'

module JsonProcessor
  class Generator
    def initialize
      @encrypted_password = read_from_file('_plugins/xyz/1.txt')
      @key = read_from_file('_plugins/xyz/2.txt')
      @iv = read_from_file('_plugins/xyz/3.txt')
    end

    def read_from_file(filename)
      File.read(filename)
    end

    def decrypt_password(encrypted_password, key, iv)
      decipher = OpenSSL::Cipher.new('AES-256-CBC')
      decipher.decrypt
      decipher.key = key
      decipher.iv = iv

      decipher.update(encrypted_password) + decipher.final
    end

    def decode_api_key
      decrypted_password = decrypt_password(@encrypted_password, @key, @iv)
      Base64.decode64(decrypted_password)
    end

    def fetch_and_save_json(url)
      begin
        api_key = decode_api_key
        main_url = "https://sheets.googleapis.com/v4/spreadsheets/102jPm41ih-0yhYSZC3gkI6UJgRcZA4W5k4wX8vHyeaw/values/data?key=#{api_key}"

        json_data = JSON.parse(URI.open(main_url).read)
        values_data = json_data['values']

        File.open('_data/data.json', 'w') { |file| file.write(JSON.pretty_generate({ 'values' => values_data })) }

        generate_from_local('_data/data.json')
      rescue StandardError => e
        puts "Error fetching or processing data: #{e.message}"
      end
    end

    def generate_from_local(file_path)
        begin
          json_data = JSON.parse(File.read(file_path))
          
          # Remove the entire work directory and its contents
          FileUtils.rm_rf('work')
      
          values = json_data['values']
      
          values.each do |item_data|
            title = item_data[0].downcase.gsub(/\s+/, '-') # Formatting the first value as per your request
      
            folder_path = File.join('work', title)
            FileUtils.mkdir_p(folder_path)
      
            generated_html = generate_html(item_data)
      
            File.open(File.join(folder_path, 'index.html'), 'w') do |file|
              file.write(generated_html)
            end
          end
        rescue StandardError => e
          puts "Error fetching or processing data: #{e.message}"
        end
      end
      
      def generate_html(item_data)
        demo_html = File.read('demo/index.html')
        replacements = {}
      
        # Generating placeholders for each value dynamically
        item_data.each_with_index do |value, index|
          key = "{{ value[#{index}] }}"
          value = value.downcase.gsub(/\s+/, '-') if index == 1 # Formatting value[1]
          replacements[key] = value
        end
      
        replacements.each { |placeholder, value| demo_html.gsub!(placeholder, value) }
        demo_html
      end
  end
end

# Instantiate the generator and call the fetch_and_save_json method with the URL
generator = JsonProcessor::Generator.new
generator.fetch_and_save_json('https://example.com/your_data.json')
